<html>
    

<head>
    <style>
        a{
            text-decoration:none;
            font-size:20px;
            color:#3399ff;

        }

        a.nav-btn{
            float:right;
            
        }
    </style>
</head>
<body>



<ul>
                <a href="../../mainpage.php" class="nav-btn">&nbsp Main Page &nbsp</a> 
                <a href="Login.php" class="nav-btn">&nbsp Login &nbsp</a>               
                <a href="Registration.php" class="nav-btn">&nbsp Registration &nbsp</a>
                <br><br> 
  </ul>



</body>
</html>