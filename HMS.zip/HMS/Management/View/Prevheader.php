<html>
    

<head>
    <style>
        a{
            text-decoration:none;
            font-size:20px;
            color:Black;
            margin-top:10px;

        }

        a.nav-btn{
            float:left;
            
        }
        table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td{
  border: 1px solid #99ddff;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color:#99ddff ;
}
th{
    text-align: center;
    background-color:#00aaff;
    text-align: center;
     padding: 8px;
}
td{
    text-align: center;

}
ul{
    background-color:#99ddff;
    height:50px;
}
input{
    border-radius:5px;
    border:none;
}
    </style>
</head>
<body>



<ul>
                <a href="../../mainpage.php" class="nav-btn">&nbsp Main Page &nbsp</a> 
                <a href="Login.php" class="nav-btn">&nbsp Login &nbsp</a>               
                <a href="Registration.php" class="nav-btn">&nbsp Registration &nbsp</a>
                <br><br> 
  </ul>



</body>
</html>