<!DOCTYPE html>
<html lang="en">

<head>
    <style>
        a{
            text-decoration:none;
            font-size:20px;
            margin-top:50px;
            color:black;
          
        }
        
    </style>
</head>

<body>
    <div class="nav">
                 <a href="../../mainpage.php" class="nav-btn">&nbsp Main Page &nbsp</a> 
                <a href="Login.php">&nbsp Login &nbsp</a>
                <a href="Registration.php">Registration</a>


    </div>    

</body>

</html>