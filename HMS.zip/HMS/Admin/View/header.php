<html>
    

<head>
    <style>
        a{
            text-decoration:none;
            font-size:20px;
            color:#3399ff;

        }

        a.nav-btn{
            float:right;
            
        }
    </style>
</head>
<body>
<ul>
            <a href="../../mainpage.php" class="nav-btn">&nbsp Main Page &nbsp</a> 
                <a href="../Controller/Logout.php" class="nav-btn">&nbsp Logout &nbsp</a>               
                <a href="UpdateProfile.php" class="nav-btn">&nbsp Profile &nbsp</a> 
                <a href="../../patient/view/contact.php" class="nav-btn">&nbsp Contact us &nbsp</a> 
                <a href="Home.php" class="nav-btn">&nbsp Home &nbsp</a>
                <br><br> 
  </ul>



</body>
</html>