<html>
    <head>
        <style>

            body 
{
  background-color: lightblue;
  background-image: url("Home.jpg");
  background-size: 2000px;
  background-repeat: no-repeat;
  background-position: right-center;
}
            a{
                font-size:25px;
                text-decoration:none;
            }
        </style>
    </head>

    <body>
       <center> <h1>Hospital Management System </h1>
       <br><br><br><br><br><br>

       <a href="Management/View/Login.php">Managemment Board</a><br>
       <a href="Admin/View/Login.php">Admin Panel</a><br>
       <a href="Doctor/View/Login.php">Doctors Dashboard</a><br>
       <a href="Patient/View/PatientSignIn.php">Patient Dashboard</a><br>

       </center>
    </body>
</html>